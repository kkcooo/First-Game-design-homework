﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class plane : MonoBehaviour
{
    public GameObject myCube;
    public int myCubePositionX;
    public int myCubePositionY =30;
    public int myCubePositionZ;

   

    // Start is called before the first frame update
    void Start()
    {
        GameObject.Find("Plane").AddComponent<MeshCollider>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))//鼠标左键点下
        {
            //从摄像机向鼠标位置发射射线  
            Ray mRay = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit mHit;
            //射线检验  
            if (Physics.Raycast(mRay, out mHit))
            {
                if (mHit.collider.gameObject.tag == "Plane") //生成立方体
                {
                    CreatCube();      
                }
            }
        }

    }
    void CreatCube()
    {
        myCubePositionX = Random.Range(-9, 9);
        myCubePositionZ = Random.Range(-9, 9);
        Vector3 myCubePosition = new Vector3(myCubePositionX, myCubePositionY, myCubePositionZ);
        Quaternion myCubeRotation = new Quaternion(0, 0, 0, 0);
        GameObject Cube = GameObject.Instantiate(myCube, myCubePosition, myCubeRotation) as GameObject;
    }
}
