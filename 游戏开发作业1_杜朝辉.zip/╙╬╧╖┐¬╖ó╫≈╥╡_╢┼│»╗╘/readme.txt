    老师好！
    我是杜朝辉，选择完成A类作业。
    游戏已经发布在github上了，网址是https://github.com/kkcooo/First-Game-development-homework。
    发给您的是完整的游戏。

    玩法：wasd控制移动
              鼠标点击地面生成从天而降的方块
              在方块落地之前接住它
    esc退出
    r重新开始
   

    祝老师工作顺利！

